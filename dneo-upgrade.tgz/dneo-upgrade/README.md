# desknet's NEO V9.6 R1.0 → V9.7 R1.0 upgrade scripts

These scripts run the full vendor procedure on the server (Linux + PostgreSQL 16):
- [Update tool install](https://www.desknets.com/neo/download/doc/install/dneo_linuxpg_update95.html)
- [Pre-update checklist](https://www.desknets.com/neo/download/doc/updv90/upd_checksheet.html)
- [Update operation](https://www.desknets.com/neo/download/doc/updv90/oparation.html)
- [Post-update tasks](https://www.desknets.com/neo/download/doc/updv90/outline.html)

Playwright drives the update tool's web screens with headless Chromium on the server itself. The script
stops and asks you before **completion processing**, because that step can't be undone; after it, only
the AMI gets you back to V9.6.

## Quick start (EC2 Instance Connect)

```bash
curl -fL -o /tmp/dneo-upgrade.tgz 'PRESIGNED_S3_LINK' && echo 'SHA256  /tmp/dneo-upgrade.tgz' | sha256sum -c && sudo tar xzf /tmp/dneo-upgrade.tgz -C /root && sudo tmux new -A -s dneo -c /root/dneo-upgrade
```
Inside tmux (already root):
```bash
bash upgrade.sh prep      # no downtime
bash upgrade.sh window    # after the AMI is available and the scheduler is stopped in NEO admin
```
Reconnect after a dropped session: `sudo tmux new -A -s dneo -c /root/dneo-upgrade`.

## Files

| File | What it does |
|---|---|
| `upgrade.sh` | Entry point. `sudo bash upgrade.sh <command>`. Logs to `/var/log/dneo-upgrade/<time>-<command>/` |
| `config.env` | Settings. Leave a value empty to auto-detect it |
| `lib.sh` | Shared helpers (cron handling, service restore, HTTP, psql) |
| `phases/10_precheck.sh` | Read-only checks. Detects paths, PostgreSQL, version, disk space |
| `phases/20_stop.sh` | Starts the window: confirmations, user block, scheduler/cron off, `dneows` stop |
| `phases/30_install_tool.sh` | Downloads, checks and installs `dneoupd` (vendor steps 1–3), limits it to localhost |
| `phases/40_setup_playwright.sh` | Python venv + Playwright + Chromium in `/opt/dneo-upgrade` |
| `phases/50_wizard.sh` + `wizard.py` | Runs installer screens 1–8 and screenshots each one |
| `phases/60_post.sh` | Checks the version and tool logs, restores cron/`dneows`, re-opens access |

## Steps

### 1. Copy to the server

```bash
cd /Users/aiemaan/dev/aws-instance && tar czf dneo-upgrade.tgz dneo-upgrade
```
```bash
scp -i dn_srv_my.pem dneo-upgrade.tgz ec2-user@SERVER_IP:/tmp/
```
On the server:
```bash
sudo mkdir -p /root/dneo-upgrade && sudo tar xzf /tmp/dneo-upgrade.tgz -C /root
```

### 2. Before the window (no downtime, safe on production)

```bash
cd /root/dneo-upgrade
sudo bash upgrade.sh precheck          # fix every FAIL; set MOBILE_DIR / ANPI_DIR if you use them
sudo bash upgrade.sh setup-playwright  # needs internet; ~500MB under /opt/dneo-upgrade
sudo bash upgrade.sh install-tool      # tool is reachable from this server only
sudo bash upgrade.sh discover          # fills screens 1-2, submits nothing
```

After `discover`, open the newest `/var/log/dneo-upgrade/*-discover/screens/` folder and check
`03_environment_filled.png`: every path should be filled correctly. Each line in the run log shows
which field got which value. If the script couldn't recognise a field, it stops and prints the field's
`name`. Add those fields to an overrides file (see below).

### 3. Rehearse on a clone (strongly recommended)

Launch a test instance from a fresh AMI and run `sudo bash upgrade.sh all` there. You get:
- a check of screens 3–8, which `discover` can't reach without starting the update
- the real duration of the data conversion, so you can plan the window
- the full screenshot set to compare with production

### 4. The window

1. Create the AMI in the AWS console and wait until it shows **available**.
2. In NEO admin, stop スケジューラ, 文書管理自動取込 and メール自動受信. Make sure メール索引の最適化 isn't running.
3. Run:
   ```bash
   sudo bash upgrade.sh all
   ```
   It asks you to confirm the AMI and the checklist. It shows the update results, then waits for you
   to type `COMPLETE` before completion processing. Run it inside `tmux` or `screen`, so a dropped
   SSH connection doesn't kill a long conversion.
4. Do the manual items printed at the end (start the scheduler, iCalendar/option batch/client tools,
   Node.js for AppSuite, resume AV/backups).

You can also run the window step by step: `stop` → `wizard` → `post`.

## Commands and options

| Command | Downtime | Notes |
|---|---|---|
| `precheck` | no | Asks for the PostgreSQL admin password and checks it |
| `setup-playwright` | no | Falls back to EPEL `chromium-headless` (asks first) if the bundled Chromium won't start |
| `install-tool` | no | Backs up any old `dneoupd`/`dneoupdres` to `/var/lib/dneo-upgrade/backup-*` |
| `discover` | no | Screens 1–2 only |
| `stop` | starts | Blocks `/cgi-bin/` for everyone except this server (+ `MAINT_ALLOW_IPS`) |
| `wizard` | yes | `--manual-wizard` to click through yourself; `--auto-complete` to skip the COMPLETE prompt |
| `post` | ends | Asks before re-opening access if the version shown isn't V9.7 R1.0 |
| `all` | full | precheck → install-tool → stop → wizard → post |
| `rollback-services` | ends | Undoes `stop` only. Use it to abort **before** the update starts |

`--yes` answers the checklist confirmations. It never answers `COMPLETE` or `CONTINUE`.

## What the installer automation does on each screen

| Screen | Action |
|---|---|
| 1 Intro | 次へ進む |
| 2 Environment | Fills the paths (main body, mobile, 安否確認, web home), DB admin user and password, matched by the label next to each field. Stops if it's still on this screen afterwards (wrong password or path) |
| 3 Backup settings | Ticks バックアップを行う, fills the PostgreSQL path, accepts the confirmation dialog |
| 4 Backup results | Waits until nothing shows 実行中. Any line with 失敗/異常終了/中断 → you must type `CONTINUE` |
| 5 Confirm update | 次へ進む + OK |
| 6 Progress | Checks every 30 s until every status is 終了. If the page stops refreshing for 20 min, reopens the tool main menu (the update keeps running). Shows failure lines, then waits for `COMPLETE` |
| 7 Completion | Leaves "delete backup files" unticked (`--delete-backup` to tick it), 次へ進む + OK |
| 8 Results | Waits for 終了. If any line mentions failure or コピー (module copy failed), it stops with exit code 3 |

Exit codes: `0` done, `2` stopped for review, `3` the tool reported problems, `1` script error.
Services stay stopped on any non-zero exit.

### Field overrides

The screens' HTML isn't documented, so fields are matched by their label text. If a field isn't
recognised, set exact values by CSS selector in a JSON file, then set `FIELD_OVERRIDES=/root/dneo-upgrade/overrides.json`:

```json
{
  "environment":        { "input[name=xxx]": "/var/www/cgi-bin/dneo" },
  "backup_settings":    { "input[name=bkdir]": "/var/backup/dneo" },
  "completion_confirm": { "input[name=delbk]": false }
}
```
Values can use `${VAR}` from the environment. `true`/`false` set checkboxes.

## If something goes wrong

| Situation | What to do |
|---|---|
| Precheck/stop fails before the update starts | Fix it, re-run. To give NEO back to users: `rollback-services` |
| Stopped on screen 2–4 | Nothing in NEO has changed yet. Check the screenshots, fix the setting, re-run `wizard`, or `rollback-services` |
| Stopped after screen 5 (update running or done) | Don't re-open user access. Use `--manual-wizard` (SSH tunnel) to finish from the tool's main menu, or restore the DB from the tool's backup (main menu → バックアップからの復元) |
| Module copy failed on screen 8 | The screen lists source → destination paths. Copy them by hand (`cp -a`), `chown -R apache:apache`, then run `post` |
| Anything after completion processing | Restore the AMI. That's the only way back to V9.6 |

## Notes

- **Scheduler**: the vendor guide registers `zscheduler.sh` in the **apache** user's crontab. `stop`
  comments out uncommented lines matching `CRON_PATTERN` in root's and apache's crontabs and `/etc/cron.d`,
  marks them with `#DNEOUPG#`, and `post` restores exactly those lines. The default pattern also
  matches jobs that touch `/cgi-bin/dneo` (e.g. backups). That's intended, because backups should pause too.
  `precheck` lists what will match.
- **Paths**: only `dneo.cgi` is detected for sure. If you use the mobile browser version or the safety
  confirmation feature, `precheck` lists the other CGI directories so you can set `MOBILE_DIR`/`ANPI_DIR`.
- **PostgreSQL** is detected from the running server (data dir, port and binary path of the
  PostgreSQL 16 postmaster). The installer needs the **superuser** (`postgres`), not the NEO DB user.
- **HTTPS**: if Apache redirects `http://127.0.0.1` to `https://<name>`, the scripts use `<name>` but
  resolve it to 127.0.0.1, so the tool's `Require local` limit still applies.
- **Leftovers**: `/etc/httpd/conf.d/zz-dneoupd-local.conf` stays, so the update tool remains local-only.
  Playwright is in `/opt/dneo-upgrade`, and state (crontab copies, package, backups) is in `/var/lib/dneo-upgrade`.
