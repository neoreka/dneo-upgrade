#!/bin/bash
# Shared helpers for the desknet's NEO upgrade scripts. Sourced, not run.
set -Eeuo pipefail

UPG_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=config.env
source "$UPG_DIR/config.env"

TOOL_CONF="$HTTPD_CONF_D/zz-dneoupd-local.conf"
MAINT_CONF="$HTTPD_CONF_D/zz-dneo-maintenance.conf"
CRON_MARK='#DNEOUPG# '

say()     { printf '%s\n' "$*"; }
info()    { printf '[%s] %s\n' "$(date +%T)" "$*"; }
warn()    { printf '[%s] WARN  %s\n' "$(date +%T)" "$*"; }
die()     { printf '[%s] ERROR %s\n' "$(date +%T)" "$*" >&2; exit 1; }
section() { printf '\n== %s ==\n' "$*"; }
gib()     { awk -v b="${1:-0}" 'BEGIN{printf "%.1f GiB", b/1073741824}'; }

[ "$(id -u)" -eq 0 ] || die "run as root:  sudo bash $0"
mkdir -p "$STATE_DIR" "$LOG_ROOT"
chmod 700 "$STATE_DIR"
RUN_DIR=${RUN_DIR:-$LOG_ROOT/$(date +%Y%m%d-%H%M%S)-$(basename "$0" .sh)}
mkdir -p "$RUN_DIR"

has_tty() { { : < /dev/tty; } 2>/dev/null; }

# confirm "question" [WORD] - the operator must type WORD. --yes only skips "yes" gates.
confirm() {
  local q=$1 word=${2:-yes} ans
  if [ "${DNEO_ASSUME_YES:-0}" = 1 ] && [ "$word" = yes ]; then
    info "(--yes) $q"
    return 0
  fi
  has_tty || die "needs an interactive terminal to confirm: $q"
  printf '\n%s\n  Type %s to continue: ' "$q" "$word" > /dev/tty
  read -r ans < /dev/tty
  [ "$ans" = "$word" ] || die "not confirmed - stopped."
}

# Fill empty settings from detected.env (written by precheck). Not sourced: values are data.
load_detected() {
  local f="$STATE_DIR/detected.env" k v
  [ -f "$f" ] || die "no detected settings - run:  sudo bash upgrade.sh precheck"
  while IFS='=' read -r k v; do
    [[ $k =~ ^[A-Z_]+$ ]] || continue
    [ -n "${!k:-}" ] || printf -v "$k" '%s' "$v"
  done < "$f"
  TOOL_URL="${TOOL_SCHEME}://${TOOL_HOST}${CGI_URL}/dneoupd/dneoupd.cgi"
  NEO_URL_PATH="${CGI_URL}/$(basename "$NEO_DIR")/dneo.cgi"
}

ask_db_pass() {
  [ -n "${DNEO_DB_PASS:-}" ] && return 0
  has_tty || die "set DNEO_DB_PASS or run from a terminal"
  read -rsp "PostgreSQL admin password for '$DB_ADMIN_USER': " DNEO_DB_PASS < /dev/tty
  echo > /dev/tty
  export DNEO_DB_PASS
}

pg_q() {
  PGPASSWORD=$DNEO_DB_PASS PGCONNECT_TIMEOUT=10 "$PG_HOME/bin/psql" -X -w -h 127.0.0.1 \
    -p "$PG_PORT" -U "$DB_ADMIN_USER" -d postgres -Atqc "$1"
}

# curl against the local Apache, keeping the Host name Apache expects.
local_curl() {
  local args=(-sk --max-time 30)
  if [ "$TOOL_HOST" != 127.0.0.1 ] && [ "$TOOL_HOST" != localhost ]; then
    args+=(--resolve "$TOOL_HOST:80:127.0.0.1" --resolve "$TOOL_HOST:443:127.0.0.1")
  fi
  curl "${args[@]}" "$@"
}
http_code() { local_curl -o /dev/null -w '%{http_code}' "${TOOL_SCHEME}://${TOOL_HOST}$1" || echo 000; }
http_body() { local_curl "${TOOL_SCHEME}://${TOOL_HOST}$1" || true; }

# Prints the first "V9.x Rx.x" seen on the NEO login page, or nothing.
neo_version() {
  http_body "$NEO_URL_PATH" | grep -oE 'V[0-9]+\.[0-9]+ ?R[0-9]+\.[0-9]+' | head -1 | sed -E 's/ ?R/ R/' || true
}

httpd_reload() {
  if apachectl configtest >/dev/null 2>&1; then
    systemctl reload httpd
  else
    apachectl configtest || true
    die "Apache config test failed - not reloading"
  fi
}

# ---- cron: comment out / restore scheduler lines ------------------------------
cron_mark_awk='!/^[[:space:]]*#/ && $0 ~ pat { print mark $0; next } { print }'
cron_unmark_awk='index($0, mark) == 1 { print substr($0, length(mark) + 1); next } { print }'

cron_disable() {
  local u f cur new n
  for u in root "$WEBUSER"; do
    cur=$(crontab -l -u "$u" 2>/dev/null) || continue
    [ -f "$STATE_DIR/crontab.$u.orig" ] || printf '%s\n' "$cur" > "$STATE_DIR/crontab.$u.orig"
    new=$(awk -v pat="$CRON_PATTERN" -v mark="$CRON_MARK" "$cron_mark_awk" <<<"$cur")
    n=$(grep -c "^$CRON_MARK" <<<"$new" || true)
    if [ "$new" != "$cur" ]; then
      printf '%s\n' "$new" | crontab -u "$u" -
      info "crontab($u): commented out $n line(s):"
      grep "^$CRON_MARK" <<<"$new" | sed 's/^/    /'
    else
      info "crontab($u): nothing matches /$CRON_PATTERN/"
    fi
  done
  for f in /etc/cron.d/*; do
    [ -f "$f" ] || continue
    grep -Eq "$CRON_PATTERN" "$f" || continue
    new=$(awk -v pat="$CRON_PATTERN" -v mark="$CRON_MARK" "$cron_mark_awk" "$f")
    [ "$new" != "$(cat "$f")" ] || continue
    [ -f "$STATE_DIR/crond.$(basename "$f").orig" ] || cp -p "$f" "$STATE_DIR/crond.$(basename "$f").orig"
    printf '%s\n' "$new" > "$f"
    grep -qxF "$f" "$STATE_DIR/crond.list" 2>/dev/null || echo "$f" >> "$STATE_DIR/crond.list"
    info "$f: commented out matching line(s)"
  done
}

cron_restore() {
  local u f cur
  for u in root "$WEBUSER"; do
    cur=$(crontab -l -u "$u" 2>/dev/null) || continue
    grep -q "^$CRON_MARK" <<<"$cur" || continue
    awk -v mark="$CRON_MARK" "$cron_unmark_awk" <<<"$cur" | crontab -u "$u" -
    info "crontab($u): scheduler line(s) restored"
  done
  if [ -f "$STATE_DIR/crond.list" ]; then
    while read -r f; do
      [ -f "$f" ] || continue
      awk -v mark="$CRON_MARK" "$cron_unmark_awk" "$f" > "$f.dneoupg" && cat "$f.dneoupg" > "$f" && rm -f "$f.dneoupg"
      info "$f: restored"
    done < "$STATE_DIR/crond.list"
    rm -f "$STATE_DIR/crond.list"
  fi
}

# ---- undo everything `stop` did (used by post and rollback-services) ----------
restore_services() {
  section "Restore services"
  cron_restore
  if [ -f "$STATE_DIR/dneows.state" ]; then
    local active enabled
    read -r active enabled < "$STATE_DIR/dneows.state"
    [ "$enabled" = enabled ] && systemctl enable "$REALTIME_SERVICE" >/dev/null 2>&1 || true
    if [ "$active" = active ]; then
      systemctl start "$REALTIME_SERVICE" && info "$REALTIME_SERVICE started" || warn "$REALTIME_SERVICE failed to start: systemctl status $REALTIME_SERVICE"
    fi
    rm -f "$STATE_DIR/dneows.state"
  fi
  if [ -f "$MAINT_CONF" ]; then
    rm -f "$MAINT_CONF"
    httpd_reload
    info "user access re-opened (removed $MAINT_CONF)"
  fi
  rm -f "$STATE_DIR/stopped"
}
