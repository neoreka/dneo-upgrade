#!/bin/bash
# =============================================================================
# desknet's NEO V9.6 R1.0 -> V9.7 R1.0 upgrade (Linux + PostgreSQL 16)
#
# Usage (as root, inside tmux):  bash upgrade.sh <command> [options]
#
#  The two commands you normally need:
#   prep               no downtime: precheck -> setup-playwright -> install-tool -> discover
#   window             the downtime: precheck -> stop -> wizard -> post
#                      (needs a passed 'prep' and must run inside tmux/screen)
#
#  Single steps (same thing, one at a time):
#   precheck           read-only checks; detects paths -> /var/lib/dneo-upgrade/detected.env
#   setup-playwright   install Python + Playwright + headless Chromium in /opt/dneo-upgrade
#   install-tool       download, check and install the V9.7 update tool (local access only)
#   discover           open installer screens 1-2, fill them, save screenshots; submits nothing
#   stop               confirm AMI/manual steps, block users, stop scheduler + dneows
#   wizard             run the installer screens (asks before completion processing)
#   post               verify, restore cron/dneows, re-open user access
#
#  Abort before the update has started:
#   rollback-services  undo 'stop' only (NEO data is NOT restored - use the AMI for that)
#
#  Options:
#   --yes              answer "yes" to the checklist confirmation (never to COMPLETE)
#   --manual-wizard    you click through the installer in a browser via SSH tunnel
#   --auto-complete    run completion processing without asking, if no failures are shown
#   --delete-backup    let the tool delete its DB backup during completion processing
#   --allow-unmatched  leave installer fields the script doesn't recognise empty
#
# Logs: /var/log/dneo-upgrade/<time>-<command>/ (run.log + installer screens)
# =============================================================================
set -Eeuo pipefail
UPG_DIR=$(cd "$(dirname "$0")" && pwd)
HELP_LINES='2,32p'

CMD=${1:-}; [ $# -gt 0 ] && shift
WIZ_OPTS=()
for a in "$@"; do
  case "$a" in
    --yes) export DNEO_ASSUME_YES=1 ;;
    --manual-wizard|--auto-complete|--delete-backup|--allow-unmatched) WIZ_OPTS+=("$a") ;;
    -h|--help) sed -n "$HELP_LINES" "$0"; exit 0 ;;
    *) echo "unknown option: $a" >&2; exit 2 ;;
  esac
done
case "$CMD" in
  all) CMD=window ;;
  prep|window|precheck|setup-playwright|install-tool|discover|stop|wizard|post|rollback-services) ;;
  ""|-h|--help|help) sed -n "$HELP_LINES" "$0"; exit 0 ;;
  *) echo "unknown command: $CMD (see --help)" >&2; exit 2 ;;
esac
[ "$(id -u)" -eq 0 ] || { echo "run as root:  sudo tmux new -A -s dneo -c $UPG_DIR   then: bash upgrade.sh $CMD" >&2; exit 1; }

# A dropped browser/SSH session must not kill the downtime steps.
in_multiplexer() {
  local p=$$ c
  while [ "${p:-1}" -gt 1 ]; do
    c=$(ps -o comm= -p "$p" 2>/dev/null || true)
    case "$c" in tmux*|screen*|SCREEN*) return 0 ;; esac
    p=$(ps -o ppid= -p "$p" 2>/dev/null | tr -d ' ')
  done
  return 1
}
case "$CMD" in
  window|stop|wizard)
    in_multiplexer || { echo "'$CMD' must run inside tmux. Start it with:  sudo tmux new -A -s dneo -c $UPG_DIR" >&2; exit 1; } ;;
esac

# shellcheck source=config.env
source "$UPG_DIR/config.env"
export RUN_DIR="$LOG_ROOT/$(date +%Y%m%d-%H%M%S)-$CMD"
mkdir -p "$RUN_DIR" "$STATE_DIR"
exec > >(tee -a "$RUN_DIR/run.log") 2>&1
echo "== dneo-upgrade $CMD  $(date '+%F %T %Z')  host $(hostname)  log $RUN_DIR"

on_fail() {
  echo
  echo "!! '$CMD' did not finish. Log: $RUN_DIR/run.log"
  if [ -f "$STATE_DIR/stopped" ]; then
    echo "!! Services are STOPPED and users are blocked. Do not panic and do not reboot."
    echo "!! If the installer has NOT started the update yet, undo with:  bash upgrade.sh rollback-services"
    echo "!! If the update already started, leave everything as it is and get help (send run.log)."
  fi
}
trap on_fail ERR

phase() { bash "$UPG_DIR/phases/$1" "${@:2}"; }

# Ask the DB admin password once and share it with every phase that needs it.
need_pass() {
  if [ -z "${DNEO_DB_PASS:-}" ]; then
    read -rsp "PostgreSQL admin password for '$DB_ADMIN_USER': " DNEO_DB_PASS < /dev/tty
    echo > /dev/tty
    export DNEO_DB_PASS
  fi
}

case "$CMD" in
  prep)
    need_pass
    rm -f "$STATE_DIR/prep.ok"
    phase 10_precheck.sh
    phase 40_setup_playwright.sh
    phase 30_install_tool.sh
    phase 50_wizard.sh --discover "${WIZ_OPTS[@]}"
    date +%s > "$STATE_DIR/prep.ok"
    echo
    echo "== prep passed. Check the 'environment: filling fields' lines above: every path must be right."
    echo "== Next: create the AMI, stop the scheduler in NEO admin, then:  bash upgrade.sh window"
    ;;
  window)
    [ -f "$STATE_DIR/prep.ok" ] || { echo "run 'bash upgrade.sh prep' first and make sure it passes" >&2; exit 1; }
    need_pass
    phase 10_precheck.sh
    phase 30_install_tool.sh
    phase 20_stop.sh
    phase 50_wizard.sh "${WIZ_OPTS[@]}"
    phase 60_post.sh
    ;;
  precheck)          need_pass; phase 10_precheck.sh ;;
  setup-playwright)  phase 40_setup_playwright.sh ;;
  install-tool)      phase 30_install_tool.sh ;;
  discover)          need_pass; phase 50_wizard.sh --discover "${WIZ_OPTS[@]}" ;;
  stop)              phase 20_stop.sh ;;
  wizard)            need_pass; phase 50_wizard.sh "${WIZ_OPTS[@]}" ;;
  post)              phase 60_post.sh ;;
  rollback-services) phase 60_post.sh --restore-only ;;
esac
echo "== $CMD finished  $(date '+%F %T %Z')"
