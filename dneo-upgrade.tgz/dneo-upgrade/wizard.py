#!/usr/bin/env python3
"""Drive the desknet's NEO update tool (dneoupd.cgi) through its screens.

Follows updv90/oparation.html:
  1 intro  2 environment  3 backup settings  4 backup results
  5 update confirm  6 update progress  7 completion confirm  8 completion results

Run by phases/50_wizard.sh with the venv's python; settings come from DNEO_*
environment variables. Each screen is saved to --out as NN_<name>.png/.html/
.fields.json so the run can be reviewed afterwards.

Exit codes: 0 finished (or --discover done), 2 stopped for a person to look,
3 the tool reported failures, 1 unexpected error.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

from playwright.sync_api import Error as PWError
from playwright.sync_api import sync_playwright

NEXT = "次へ進む"
RUNNING = "実行中"
FINISHED = "終了"
FAIL_WORDS = ("異常終了", "失敗", "中断", "エラーが発生")

# Label keywords -> env var, per screen. First matching rule wins, so the
# more specific rules come first.
ENV_RULES = [
    ("mobile", ("モバイル",), "DNEO_MOBILE_DIR"),
    ("anpi", ("安否",), "DNEO_ANPI_DIR"),
    ("docroot", ("ホーム", "ドキュメント", "DocumentRoot"), "DNEO_DOCROOT"),
    ("db user", ("ユーザ",), "DNEO_DB_USER"),
    ("pg home", ("PostgreSQL",), "DNEO_PG_HOME"),
    ("main body", ("本体", "desknet", "インストール先"), "DNEO_NEO_DIR"),
]
BACKUP_RULES = [
    ("backup dir", ("バックアップ先", "保存先", "出力先"), "DNEO_BACKUP_DIR"),
    ("db user", ("ユーザ",), "DNEO_DB_USER"),
    ("pg home", ("PostgreSQL", "インストール"), "DNEO_PG_HOME"),
]

FIELDS_JS = r"""
() => {
  const out = [];
  document.querySelectorAll('input, select, textarea').forEach((el, i) => {
    el.setAttribute('data-dneo-idx', String(i));
    const type = (el.getAttribute('type') || el.tagName).toLowerCase();
    if (['hidden', 'submit', 'button', 'image', 'reset'].includes(type)) return;
    const txt = (n) => (n ? n.innerText || '' : '');
    let label = '';
    if (el.id) label = txt(document.querySelector(`label[for="${CSS.escape(el.id)}"]`));
    if (!label) label = txt(el.closest('label'));
    if (!label) {
      const cell = el.closest('td, th');
      if (cell) {
        let parts = [], c = cell.previousElementSibling;
        while (c) { parts.unshift(txt(c)); c = c.previousElementSibling; }
        label = parts.join(' ');
        if (['checkbox', 'radio'].includes(type)) label += ' ' + txt(cell);
      }
    }
    if (!label) label = txt(el.closest('tr')) || txt(el.parentElement);
    const r = el.getBoundingClientRect();
    out.push({
      idx: i, tag: el.tagName.toLowerCase(), type, name: el.name || '', id: el.id || '',
      value: type === 'password' ? (el.value ? '***' : '') : (el.value || ''),
      checked: !!el.checked, disabled: !!el.disabled,
      visible: r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden',
      label: label.replace(/\s+/g, ' ').trim().slice(0, 200),
    });
  });
  return out;
}
"""


class Stop(Exception):
    def __init__(self, msg, code=2):
        super().__init__(msg)
        self.code = code


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def ask_tty(question, word):
    """Operator must type `word`. Returns False when there is no terminal."""
    try:
        with open("/dev/tty", "r+") as tty:
            tty.write(f"\n{question}\n  Type {word} to continue: ")
            tty.flush()
            return tty.readline().strip() == word
    except OSError:
        return False


class Wizard:
    def __init__(self, page, args):
        self.page = page
        self.args = args
        self.out = Path(args.out)
        self.out.mkdir(parents=True, exist_ok=True)
        self.n = 0
        self.dialogs = []
        self.instruction_lines = set()
        self.overrides = {}
        if args.overrides:
            self.overrides = json.loads(Path(args.overrides).read_text(encoding="utf-8"))
        page.on("dialog", self._on_dialog)

    # ---- page helpers --------------------------------------------------------
    def _on_dialog(self, d):
        log(f"dialog ({d.type}): {d.message!r} -> OK")
        self.dialogs.append(d.type)
        d.accept()

    def text(self):
        try:
            return self.page.inner_text("body", timeout=10000)
        except PWError:
            return ""  # page is navigating

    def fields(self):
        try:
            return self.page.evaluate(FIELDS_JS)
        except PWError:
            return []

    def save(self, name):
        self.n += 1
        stem = self.out / f"{self.n:02d}_{name}"
        try:
            self.page.screenshot(path=f"{stem}.png", full_page=True)
            Path(f"{stem}.html").write_text(self.page.content(), encoding="utf-8")
            Path(f"{stem}.fields.json").write_text(
                json.dumps(self.fields(), ensure_ascii=False, indent=1), encoding="utf-8")
        except PWError as e:
            log(f"could not save {name}: {e}")
        log(f"saved {stem.name}.*   ({self.page.url})")

    def next_button(self):
        loc = self.page.locator(
            f'input[type=submit][value*="{NEXT}"], input[type=button][value*="{NEXT}"], '
            f'button:has-text("{NEXT}"), a:has-text("{NEXT}")')
        try:
            for i in range(loc.count()):
                b = loc.nth(i)
                if b.is_visible() and b.is_enabled():
                    return b
        except PWError:
            pass
        return None

    def el(self, f):
        return self.page.locator(f'[data-dneo-idx="{f["idx"]}"]')

    def set_value(self, f, value, what, secret=False):
        self.el(f).fill(value)
        log(f"  {what:<10} <- {'********' if secret else value}   [{f['label'][:60]}]")

    def advance(self, screen, timeout_s):
        """Click 次へ進む and wait until a different screen is showing."""
        btn = self.next_button()
        if not btn:
            raise Stop(f"no '{NEXT}' button on the {screen} screen")
        before = (self.page.url, self.text())
        alerts = sum(1 for t in self.dialogs if t == "alert")
        log(f"{screen}: clicking {NEXT}")
        btn.click(no_wait_after=True)
        t0 = last = time.time()
        while time.time() - t0 < timeout_s:
            time.sleep(2)
            try:
                self.page.wait_for_load_state("domcontentloaded", timeout=5000)
            except PWError:
                continue
            now = (self.page.url, self.text())
            if now[1] and now != before:
                return
            if sum(1 for t in self.dialogs if t == "alert") > alerts and time.time() - t0 > 10:
                raise Stop(f"the {screen} screen showed an alert and did not move on - see the log above")
            if time.time() - last > 300:
                last = time.time()
                log(f"{screen}: still waiting for the next screen ({int((last - t0) / 60)} min)")
        raise Stop(f"timed out after {timeout_s // 60} min waiting to leave the {screen} screen")

    def wait_finished(self, what, need_next=True):
        """Wait until nothing shows 実行中 (and 次へ進む is there, if need_next)."""
        deadline = time.time() + self.args.timeout_hours * 3600
        last_text, last_change, last_log, last_shot = None, time.time(), 0, time.time()
        self.instruction_lines = set()
        while True:
            t = self.text()
            if t and t != last_text:
                last_text, last_change = t, time.time()
            running = t.count(RUNNING)
            if running:
                # Failure words visible while still running are instructions, not results.
                self.instruction_lines |= set(self.problem_lines(t, FAIL_WORDS + ("コピー",)))
            if t and running == 0 and (self.next_button() if need_next else FINISHED in t):
                return t
            now = time.time()
            if now > deadline:
                raise Stop(f"{what}: still not finished after {self.args.timeout_hours} h")
            if now - last_log > 300:
                last_log = now
                log(f"{what}: {running} running, {t.count(FINISHED)} finished")
            if now - last_shot > 1800:
                last_shot = now
                self.save(f"{what}_progress")
            if running and now - last_change > self.args.stall_minutes * 60:
                self.reopen_results(what)
                last_change = time.time()
            time.sleep(self.args.poll)

    def reopen_results(self, what):
        """The progress page stopped refreshing: reopen the tool (GET is safe,
        the update keeps running) and follow the link to the processing results."""
        log(f"{what}: page unchanged for {self.args.stall_minutes} min - reopening {self.args.url}")
        self.page.goto(self.args.url, wait_until="domcontentloaded")
        self.save("main_menu")
        link = self.page.locator("a:has-text('処理結果'), a:has-text('実行結果'), a:has-text('進捗')")
        if link.count() == 0:
            raise Stop("tool main menu has no link to the processing results - continue in a browser "
                       "(see README: manual wizard)")
        link.first.click()
        self.page.wait_for_load_state("domcontentloaded")

    # ---- form filling ----------------------------------------------------------
    def fill_text_fields(self, fields, rules, screen):
        unmatched = []
        for f in fields:
            if not f["visible"] or f["disabled"] or f["type"] in ("checkbox", "radio", "select", "file"):
                continue
            if f["type"] == "password":
                self.set_value(f, os.environ["DNEO_DB_PASS"], "password", secret=True)
                continue
            rule = next((r for r in rules if any(k in f["label"] for k in r[1])), None)
            if not rule:
                if not f["value"]:
                    unmatched.append(f)
                continue
            want = os.environ.get(rule[2], "")
            if not want:
                log(f"  {rule[0]:<10} (not configured - left as '{f['value']}')   [{f['label'][:60]}]")
            elif f["value"].rstrip("/") == want.rstrip("/"):
                log(f"  {rule[0]:<10} already {f['value']}")
            else:
                if f["value"]:
                    log(f"  {rule[0]:<10} replacing pre-filled '{f['value']}'")
                self.set_value(f, want, rule[0])
        self.apply_overrides(screen)
        if unmatched:
            for f in unmatched:
                log(f"  UNMATCHED empty field name={f['name']!r} id={f['id']!r} label={f['label']!r}")
            if not self.args.allow_unmatched:
                raise Stop(f"{screen}: empty field(s) I don't recognise - add them to FIELD_OVERRIDES "
                           "or re-run with --allow-unmatched")

    def apply_overrides(self, screen):
        for selector, value in self.overrides.get(screen, {}).items():
            loc = self.page.locator(selector)
            if isinstance(value, bool):
                loc.set_checked(value)
            else:
                loc.fill(os.path.expandvars(str(value)))
            log(f"  override   {selector} <- {value}")

    def checkbox(self, fields, must_have, must_not=()):
        for f in fields:
            if f["type"] == "checkbox" and f["visible"] and must_have in f["label"] \
                    and not any(w in f["label"] for w in must_not):
                return f
        return None

    # ---- checks ---------------------------------------------------------------
    @staticmethod
    def problem_lines(t, words=FAIL_WORDS):
        return [ln.strip() for ln in t.splitlines() if any(w in ln for w in words)]

    def new_problems(self, t, words=FAIL_WORDS):
        return [ln for ln in self.problem_lines(t, words) if ln not in self.instruction_lines]

    @staticmethod
    def show_screen(t, title):
        """Print the screen's text so it can be checked in a plain terminal."""
        lines = [" ".join(ln.split()) for ln in t.splitlines()]
        lines = [ln for ln in lines if ln]
        print(f"\n----- {title} (screen text) -----", flush=True)
        for ln in lines[:120]:
            print(f"  {ln}", flush=True)
        if len(lines) > 120:
            print(f"  ... {len(lines) - 120} more lines in the saved .html", flush=True)
        print("-" * (len(title) + 26), flush=True)

    def review(self, t, what, word):
        """Show lines mentioning failures; the operator decides whether to go on."""
        bad = self.new_problems(t)
        if not bad:
            log(f"{what}: no failure words on the screen")
            return
        self.show_screen(t, what)
        log(f"{what}: these lines mention a failure (they may be just instructions):")
        for ln in bad[:30]:
            log(f"    | {ln}")
        if not ask_tty(f"Read the {what} screen above. Nothing in NEO has changed yet. Continue anyway?", word):
            raise Stop(f"{what}: stopped at the operator's request (or no terminal)", 3)

    # ---- the run ---------------------------------------------------------------
    def run(self):
        a, p = self.args, self.page
        long_wait = a.timeout_hours * 3600

        log(f"opening {a.url}")
        p.goto(a.url, wait_until="domcontentloaded", timeout=60000)
        self.save("intro")
        if any(f["type"] == "password" for f in self.fields()):
            log("tool opened directly on the environment screen")
        else:
            if not self.next_button():
                raise Stop("the first screen has no 次へ進む - the tool may be showing its main menu "
                           "from an earlier update. Look at 01_intro.png and continue manually.")
            self.advance("intro", 600)

        # 2 - environment: install paths and DB admin user/password
        self.save("environment")
        fields = self.fields()
        if not any(f["type"] == "password" for f in fields):
            raise Stop("expected the environment screen (DB admin password field) - see the screenshot")
        log("environment: filling fields")
        self.fill_text_fields(fields, ENV_RULES, "environment")
        self.save("environment_filled")
        if a.discover:
            log("--discover: stopping before submitting anything. Check the filled values above.")
            return 0
        self.advance("environment", 1800)
        if any(f["type"] == "password" and f["visible"] for f in self.fields()):
            self.save("environment_error")
            raise Stop("still on the environment screen after 次へ進む - probably a wrong path or password; "
                       "see the screenshot")

        # 3 - backup settings
        self.save("backup_settings")
        fields = self.fields()
        cb = self.checkbox(fields, "バックアップ", must_not=("削除",))
        if not cb:
            raise Stop("no 'バックアップを行う' checkbox found on the backup settings screen")
        self.el(cb).check()
        log(f"  backup     [x] {cb['label'][:60]}")
        self.fill_text_fields(self.fields(), BACKUP_RULES, "backup_settings")
        self.save("backup_settings_filled")
        self.advance("backup settings", long_wait)  # dialog OK is automatic

        # 4 - backup results (nothing in NEO has changed yet)
        t = self.wait_finished("backup")
        self.save("backup_results")
        self.review(t, "backup results", "CONTINUE")
        self.advance("backup results", 1800)

        # 5 - confirm the update
        self.save("update_confirm")
        self.advance("update confirm", long_wait)

        # 6 - update progress -> all 終了
        t = self.wait_finished("update")
        self.save("update_results")
        bad = self.new_problems(t)
        self.show_screen(t, "update results")
        log(f"update: finished - {t.count(FINISHED)} x 終了, {len(bad)} line(s) mentioning failure")
        for ln in bad[:30]:
            log(f"    | {ln}")
        verdict = ("NO failures found" if not bad
                   else f"{len(bad)} LINE(S) MENTION A FAILURE - do NOT type COMPLETE unless you are sure")
        if a.auto_complete and not bad:
            log("--auto-complete: going on to completion processing")
        elif not ask_tty(
                f"Update processing is done: {verdict}.\n"
                "Every item above must show 終了, none 異常終了 / 中断.\n"
                "Completion processing installs the new modules and CANNOT be undone (only the AMI can).\n"
                "To stop here instead, just press Enter.", "COMPLETE"):
            raise Stop("stopped before completion processing. Finish later with:  upgrade.sh wizard "
                       "(or the tool's main menu link to completion processing)", 3 if bad else 2)
        self.advance("update results", 1800)

        # 7 - completion processing (keep the DB backup unless --delete-backup)
        self.save("completion_confirm")
        fields = self.fields()
        del_cb = self.checkbox(fields, "削除")
        if del_cb:
            self.el(del_cb).set_checked(a.delete_backup)
            log(f"  delete backup files: {'yes' if a.delete_backup else 'no'}")
        self.apply_overrides("completion_confirm")
        self.advance("completion confirm", long_wait)

        # 8 - completion results
        t = self.wait_finished("completion", need_next=False)
        self.save("completion_results")
        bad = self.new_problems(t)
        copy_msg = self.new_problems(t, ("コピー",))
        if bad or copy_msg:
            for ln in (bad + copy_msg)[:40]:
                log(f"    | {ln}")
            raise Stop("completion processing reported problems. If module copies failed, copy each "
                       "source path to its destination as the screen says (see README).", 3)
        log("completion processing finished - every item 終了")
        return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--resolve-host", help="host name to resolve to 127.0.0.1")
    ap.add_argument("--chromium", help="Chromium executable (default: Playwright's)")
    ap.add_argument("--poll", type=int, default=30)
    ap.add_argument("--stall-minutes", type=int, default=20)
    ap.add_argument("--timeout-hours", type=int, default=24)
    ap.add_argument("--overrides", help="JSON {screen: {css selector: value}}")
    ap.add_argument("--discover", action="store_true", help="stop after filling screen 2; submit nothing")
    ap.add_argument("--auto-complete", action="store_true",
                    help="run completion processing without asking, if no failures are shown")
    ap.add_argument("--delete-backup", action="store_true", help="tick 'delete backup files' on screen 7")
    ap.add_argument("--allow-unmatched", action="store_true", help="leave unrecognised empty fields empty")
    a = ap.parse_args()
    if not os.environ.get("DNEO_DB_PASS"):
        sys.exit("DNEO_DB_PASS is not set")

    launch_args = [f"--host-resolver-rules=MAP {a.resolve_host} 127.0.0.1"] if a.resolve_host else []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True, executable_path=a.chromium or None, args=launch_args)
        ctx = browser.new_context(ignore_https_errors=True, locale="ja-JP",
                                  viewport={"width": 1280, "height": 1000})
        page = ctx.new_page()
        page.set_default_timeout(30000)
        w = Wizard(page, a)
        try:
            rc = w.run()
        except Stop as e:
            w.save("stopped")
            log(f"STOPPED: {e}")
            rc = e.code
        except Exception as e:  # noqa: BLE001 - keep a screenshot of whatever went wrong
            w.save("error")
            log(f"ERROR: {type(e).__name__}: {e}")
            rc = 1
        finally:
            browser.close()
    sys.exit(rc)


if __name__ == "__main__":
    main()
