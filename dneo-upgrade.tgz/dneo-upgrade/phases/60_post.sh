#!/bin/bash
# Phase 60 - after the installer: verify, then end the downtime window.
#   --restore-only   just undo 'stop' (cron, dneows, user block) - used by rollback-services
source "$(dirname "$0")/../lib.sh"
load_detected

if [ "${1:-}" = --restore-only ]; then
  restore_services
  info "services restored. NEO is unchanged unless the installer already ran."
  exit 0
fi

section "Verify the upgrade"
code=$(http_code "$NEO_URL_PATH")
ver=$(neo_version)
info "login page HTTP $code, version shown: ${ver:-unknown}"
if [ "$ver" != "$TARGET_VERSION" ]; then
  warn "expected $TARGET_VERSION"
  confirm "The login page doesn't show $TARGET_VERSION. Re-open user access and restart services anyway?"
fi

section "Update tool logs"
if [ -f "$STATE_DIR/wizard.start" ]; then
  since=$(cat "$STATE_DIR/wizard.start")
  marker=$(mktemp); touch -d "@$since" "$marker"
  found=0
  while IFS= read -r f; do
    e=$(grep -c '\[ERR\]' "$f" || true); w=$(grep -c '\[WARN\]' "$f" || true)
    [ "$e$w" = 00 ] && continue
    found=1
    say "  $f: $e [ERR], $w [WARN]"
    grep -h '\[ERR\]' "$f" | head -5 | sed 's/^/      /'
  done < <(find "$CGI_DIR/dneoupd" "$NEO_DIR" -xdev -type f -newer "$marker" -size -100M \
             \( -name '*.log' -o -name '*.txt' \) 2>/dev/null)
  rm -f "$marker"
  [ "$found" = 1 ] && warn "review the [ERR] lines above (also on the tool's 詳細表示 links)" || info "no [ERR]/[WARN] lines in tool logs"
else
  info "no wizard start time recorded (manual wizard?) - check the tool's 詳細表示 logs yourself"
fi

section "Ownership and SELinux"
wrong=$(find "$NEO_DIR" -xdev ! -user "$WEBUSER" -print 2>/dev/null | head -20 || true)
if [ -n "$wrong" ]; then
  warn "files in $NEO_DIR not owned by $WEBUSER (first 20):"
  say "$wrong" | sed 's/^/    /'
  say "    fix if needed:  chown -R $WEBUSER:$(id -gn "$WEBUSER") $NEO_DIR"
else
  info "everything in $NEO_DIR is owned by $WEBUSER"
fi
if [ "$SELINUX" != Disabled ] && command -v restorecon >/dev/null; then
  restorecon -R "$NEO_DIR" && info "SELinux labels restored on $NEO_DIR"
fi

restore_services

section "Smoke test"
code=$(http_code "$NEO_URL_PATH")
[ "$code" = 200 ] && info "login page answers 200" || warn "login page returned HTTP $code"
systemctl is-active -q "$REALTIME_SERVICE" 2>/dev/null && info "$REALTIME_SERVICE running" || true

section "Still to do by hand"
cat <<EOF
  1. Log in to NEO as admin, check the version, and start スケジューラ (it also starts
     itself at the first login after midnight). Re-enable 文書管理自動取込 / メール自動受信 if used.
  2. Reinstall the iCalendar add-on, option batch and client tools if you use them.
  3. AppSuite integration in workflows: update Node.js (dneo_linuxpg_nodejs22_update.html).
  4. Resume antivirus scans and backup jobs. Tell users NEO is back.
  5. Keep the AMI until users confirm everything works, then deregister it.
  6. Optional clean-up:  rm -rf /opt/dneo-upgrade   (Playwright, ~500MB)
     The update tool stays installed and limited to this server ($TOOL_CONF).
EOF
info "upgrade window closed"
