#!/bin/bash
# Phase 40 - install Python + Playwright + headless Chromium under /opt/dneo-upgrade.
# Needs internet access, no downtime. Run it days before the window. Safe to re-run.
# Remove afterwards with:  rm -rf /opt/dneo-upgrade
source "$(dirname "$0")/../lib.sh"
export PLAYWRIGHT_BROWSERS_PATH

command -v dnf >/dev/null || die "dnf not found - supported: RHEL/AlmaLinux/Rocky 8-9, Amazon Linux 2023"

pick_python() {
  local c
  for c in python3.12 python3.11 python3.10 python3.9 python3.8 python3; do
    command -v "$c" >/dev/null 2>&1 || continue
    "$c" -c 'import sys, venv, ensurepip; sys.exit(sys.version_info < (3, 8))' 2>/dev/null && { command -v "$c"; return 0; }
  done
  return 1
}

section "Python"
if ! PY=$(pick_python); then
  info "no Python >= 3.8 with venv found - installing python3.11"
  dnf install -y python3.11 python3.11-pip || dnf install -y python3.9 python3.9-pip || dnf install -y python3 python3-pip
  PY=$(pick_python) || die "could not install a usable Python (>= 3.8 with venv)"
fi
info "using $PY ($("$PY" -V 2>&1))"

section "Chromium system libraries and Japanese fonts"
# strict=0: skip names this OS release doesn't have instead of failing.
dnf install -y --setopt=strict=0 \
  alsa-lib atk at-spi2-atk at-spi2-core cairo cups-libs dbus-libs expat glib2 libdrm \
  libX11 libXcomposite libXdamage libXext libXfixes libXi libXrandr libXtst libxcb \
  libxkbcommon libxshmfence mesa-libgbm nspr nss pango \
  google-noto-sans-cjk-ttc-fonts google-noto-sans-cjk-jp-fonts ipa-gothic-fonts

section "Playwright $PLAYWRIGHT_VERSION"
if [ ! -x "$VENV/bin/python" ]; then
  "$PY" -m venv "$VENV"
fi
"$VENV/bin/python" -m pip install -q --upgrade pip
"$VENV/bin/python" -m pip install -q "playwright==$PLAYWRIGHT_VERSION"
"$VENV/bin/python" -m playwright install chromium

smoke() { # smoke [executable]
  "$VENV/bin/python" - "${1:-}" <<'PY'
import sys
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(headless=True, executable_path=sys.argv[1] or None)
    pg = b.new_page()
    pg.set_content("<p>テスト</p>")
    print("chromium", b.version, "OK")
    b.close()
PY
}

section "Smoke test"
if smoke "" 2>"$RUN_DIR/smoke.err"; then
  rm -f "$STATE_DIR/chromium.path"
else
  warn "Playwright's bundled Chromium doesn't start on this OS:"
  tail -5 "$RUN_DIR/smoke.err" | sed 's/^/    /'
  confirm "Install the distribution's headless Chromium from EPEL instead (adds the EPEL repo)?"
  dnf install -y epel-release || dnf install -y "https://dl.fedoraproject.org/pub/epel/epel-release-latest-$(rpm -E %rhel).noarch.rpm"
  dnf install -y chromium-headless
  EXE=$(ls /usr/lib64/chromium-browser/headless_shell 2>/dev/null || true)
  [ -n "$EXE" ] || die "chromium-headless installed but headless_shell not found"
  smoke "$EXE" || die "EPEL Chromium doesn't start either - use:  upgrade.sh wizard --manual-wizard"
  echo "$EXE" > "$STATE_DIR/chromium.path"
fi
info "Playwright ready in $VENV"
