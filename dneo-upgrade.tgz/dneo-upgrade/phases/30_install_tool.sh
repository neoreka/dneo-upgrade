#!/bin/bash
# Phase 30 - install the V9.7 update tool (dneo_linuxpg_update95.html, steps 1-3).
# Needs no downtime: it only adds the tool, which is limited to this server
# (RESTRICT_TOOL_LOCAL=yes). Safe to re-run.
source "$(dirname "$0")/../lib.sh"
load_detected

PKG_DIR="$STATE_DIR/pkg"
PKG="$PKG_DIR/$(basename "$TOOL_PKG_URL")"
TS=$(date +%Y%m%d-%H%M%S)

section "Download"
mkdir -p "$PKG_DIR"
if [ ! -s "$PKG" ]; then
  curl -fL --retry 3 --max-time 1800 -o "$PKG.part" "$TOOL_PKG_URL"
  mv "$PKG.part" "$PKG"
fi
SHA=$(sha256sum "$PKG" | cut -d' ' -f1)
info "$PKG ($(gib "$(stat -c %s "$PKG")"), sha256 $SHA)"
if [ -n "$TOOL_PKG_SHA256" ] && [ "$SHA" != "$TOOL_PKG_SHA256" ]; then
  rm -f "$PKG"
  die "checksum mismatch (expected $TOOL_PKG_SHA256) - deleted, re-run to download again"
fi

section "Check package contents"
gzip -t "$PKG" || { rm -f "$PKG"; die "package is corrupt - deleted, re-run to download again"; }
LIST=$(tar tzf "$PKG")
BAD=$(grep -vE '^dneoupd(/|$)' <<<"$LIST" || true)
[ -z "$BAD" ] || die "unexpected paths outside dneoupd/: $(head -3 <<<"$BAD")"
! grep -qE '(^|/)\.\.(/|$)' <<<"$LIST" || die "package contains '..' paths"
TYPES=$(tar tvzf "$PKG" | cut -c1 | sort -u)
! grep -q '[lh]' <<<"$TYPES" || die "package contains links"
grep -qx 'dneoupd/dneoupd.cgi' <<<"$LIST" || die "dneoupd/dneoupd.cgi missing from package"
grep -q '^dneoupd/dneoupdres/' <<<"$LIST" || die "dneoupd/dneoupdres/ missing from package"
info "$(wc -l <<<"$LIST") entries, all under dneoupd/"

if [ "$(cat "$STATE_DIR/tool.sha256" 2>/dev/null)" = "$SHA" ] && [ -f "$CGI_DIR/dneoupd/dneoupd.cgi" ] && [ -d "$DOCROOT/dneoupdres" ]; then
  info "this package is already installed - skipping extract"
else
  section "Back up the existing tool"
  BK="$STATE_DIR/backup-$TS"
  if [ -d "$CGI_DIR/dneoupd" ] || [ -d "$DOCROOT/dneoupdres" ]; then
    mkdir -p "$BK"
    [ -d "$CGI_DIR/dneoupd" ]    && tar czf "$BK/dneoupd.tgz" -C "$CGI_DIR" dneoupd
    [ -d "$DOCROOT/dneoupdres" ] && tar czf "$BK/dneoupdres.tgz" -C "$DOCROOT" dneoupdres
    info "saved to $BK"
  else
    info "no previous tool installed"
  fi

  section "Install"
  WEBGROUP=$(id -gn "$WEBUSER")
  # Step 1: extract into the CGI dir, overwriting the old tool
  tar xzf "$PKG" -C "$CGI_DIR" --no-same-owner
  # Step 2: owner = Apache user
  chown -R "$WEBUSER:$WEBGROUP" "$CGI_DIR/dneoupd"
  # Step 3: static files (images/JS) into the document root
  rm -rf "$DOCROOT/dneoupdres"
  mv "$CGI_DIR/dneoupd/dneoupdres" "$DOCROOT/"
  if [ "$SELINUX" != Disabled ] && command -v restorecon >/dev/null; then
    restorecon -R "$CGI_DIR/dneoupd" "$DOCROOT/dneoupdres"
  fi
  echo "$SHA" > "$STATE_DIR/tool.sha256"
  info "installed $CGI_DIR/dneoupd and $DOCROOT/dneoupdres"
fi

section "Limit the tool to this server"
if [ "$RESTRICT_TOOL_LOCAL" = yes ] && [ -d "$HTTPD_CONF_D" ]; then
  cat > "$TOOL_CONF" <<EOF
# Added by dneo-upgrade. The update tool can only be opened from this server
# (Playwright here, or your browser through an SSH tunnel).
<Location "$CGI_URL/dneoupd">
    Require local
</Location>
<Location "/dneoupdres">
    Require local
</Location>
EOF
  httpd_reload
  info "wrote $TOOL_CONF"
else
  warn "RESTRICT_TOOL_LOCAL=$RESTRICT_TOOL_LOCAL - the tool is reachable by anyone who can reach this web server"
fi

section "Verify"
code=$(http_code "$CGI_URL/dneoupd/dneoupd.cgi")
[ "$code" = 200 ] || die "$TOOL_URL returned HTTP $code - check /var/log/httpd/error_log"
title=$(http_body "$CGI_URL/dneoupd/dneoupd.cgi" | grep -oiE '<title>[^<]*' | head -1 | sed 's/<title>//I' || true)
info "update tool answers 200 at $TOOL_URL  (title: ${title:-?})"
