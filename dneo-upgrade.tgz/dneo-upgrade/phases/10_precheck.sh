#!/bin/bash
# Phase 10 - read-only checks. Detects paths and writes $STATE_DIR/detected.env.
# Changes nothing on the server. Safe to run any time, as often as you like.
source "$(dirname "$0")/../lib.sh"

FAILS=0; WARNS=0
pass()  { printf '  OK    %s\n' "$*"; }
wfail() { printf '  FAIL  %s\n' "$*"; FAILS=$((FAILS+1)); }
wwarn() { printf '  WARN  %s\n' "$*"; WARNS=$((WARNS+1)); }

section "Server"
. /etc/os-release 2>/dev/null || true
say "  Host:    $(hostname)"
say "  OS:      ${PRETTY_NAME:-unknown}"
SELINUX=$(getenforce 2>/dev/null || echo Disabled)
say "  SELinux: $SELINUX"
command -v dnf >/dev/null || wwarn "dnf not found - setup-playwright supports RHEL/AlmaLinux/Rocky 8-9 and Amazon Linux 2023 only"

# ---- Apache -----------------------------------------------------------------
section "Apache"
systemctl is-active -q httpd && pass "httpd is running" || wfail "httpd is not running"
id "$WEBUSER" >/dev/null 2>&1 && pass "web user '$WEBUSER' exists" || wfail "web user '$WEBUSER' not found (set WEBUSER in config.env)"
conf_user=$(grep -hiE '^[[:space:]]*User[[:space:]]' /etc/httpd/conf/httpd.conf 2>/dev/null | awk '{print $2}' | head -1 || true)
[ -z "$conf_user" ] || [ "$conf_user" = "$WEBUSER" ] || wwarn "httpd.conf runs as '$conf_user' but WEBUSER=$WEBUSER"
if [ -z "$CGI_DIR" ]; then
  CGI_DIR=$(grep -RhiE "^[[:space:]]*ScriptAlias[[:space:]]+$CGI_URL/" /etc/httpd/conf /etc/httpd/conf.d 2>/dev/null \
            | awk '{print $3}' | tr -d '"' | head -1 || true)
  CGI_DIR=${CGI_DIR%/}; CGI_DIR=${CGI_DIR:-/var/www/cgi-bin}
fi
if [ -z "$DOCROOT" ]; then
  DOCROOT=$(grep -hiE '^[[:space:]]*DocumentRoot' /etc/httpd/conf/httpd.conf 2>/dev/null | awk '{print $2}' | tr -d '"' | head -1 || true)
  DOCROOT=${DOCROOT%/}; DOCROOT=${DOCROOT:-/var/www/html}
fi
[ -d "$CGI_DIR" ] && pass "CGI dir       $CGI_DIR" || wfail "CGI dir $CGI_DIR not found"
[ -d "$DOCROOT" ] && pass "document root $DOCROOT" || wfail "document root $DOCROOT not found"
[ -d "$HTTPD_CONF_D" ] || wwarn "$HTTPD_CONF_D not found - access restrictions will be skipped"

# ---- desknet's NEO paths ------------------------------------------------------
section "desknet's NEO"
if [ -z "$NEO_DIR" ]; then
  if [ -f "$CGI_DIR/dneo/dneo.cgi" ]; then NEO_DIR=$CGI_DIR/dneo
  else NEO_DIR=$(find "$CGI_DIR" -maxdepth 2 -name dneo.cgi -printf '%h\n' 2>/dev/null | head -1 || true)
  fi
fi
[ -n "$NEO_DIR" ] && [ -f "$NEO_DIR/dneo.cgi" ] && pass "main body      $NEO_DIR" || wfail "dneo.cgi not found under $CGI_DIR (set NEO_DIR)"
[ -z "$MOBILE_DIR" ] || { [ -d "$MOBILE_DIR" ] && pass "mobile         $MOBILE_DIR" || wfail "MOBILE_DIR $MOBILE_DIR not found"; }
[ -z "$ANPI_DIR" ]   || { [ -d "$ANPI_DIR" ]   && pass "safety confirm $ANPI_DIR"   || wfail "ANPI_DIR $ANPI_DIR not found"; }
say "  Other CGI directories under $CGI_DIR (set MOBILE_DIR / ANPI_DIR if one of these is"
say "  the mobile browser version or the safety confirmation feature):"
for d in "$CGI_DIR"/*/; do
  d=${d%/}; n=$(basename "$d")
  case "$n" in dneoupd|"$(basename "${NEO_DIR:-x}")") continue ;; esac
  ls "$d"/*.cgi >/dev/null 2>&1 && say "      $d   ($(cd "$d" && ls *.cgi | head -3 | tr '\n' ' '))"
done
[ -d "$CGI_DIR/dneoupd" ] && say "  Existing update tool: $CGI_DIR/dneoupd (will be backed up, then overwritten)"

# ---- PostgreSQL ---------------------------------------------------------------
section "PostgreSQL"
if [ -z "$PG_HOME" ] || [ -z "$PG_PORT" ]; then
  cands=()
  for p in $(pgrep -x 'postgres|postmaster' || true); do
    pp=$(ps -o ppid= -p "$p" | tr -d ' ')
    [[ "$(ps -o comm= -p "$pp" 2>/dev/null)" =~ ^(postgres|postmaster)$ ]] && continue
    dd=$(readlink "/proc/$p/cwd"); exe=$(readlink "/proc/$p/exe")
    ver=$(cat "$dd/PG_VERSION" 2>/dev/null || echo ?)
    port=$(sed -n 4p "$dd/postmaster.pid" 2>/dev/null || echo ?)
    say "  running: pid $p  v$ver  port $port  home ${exe%/bin/*}  data $dd"
    [ "$ver" = 16 ] && cands+=("${exe%/bin/*} $port")
  done
  if [ ${#cands[@]} -eq 1 ]; then
    read -r det_home det_port <<<"${cands[0]}"
    PG_HOME=${PG_HOME:-$det_home}; PG_PORT=${PG_PORT:-$det_port}
  else
    wfail "found ${#cands[@]} running PostgreSQL 16 servers - set PG_HOME and PG_PORT in config.env"
  fi
fi
if [ -n "$PG_HOME" ] && [ -x "$PG_HOME/bin/psql" ]; then
  pass "PostgreSQL home $PG_HOME, port $PG_PORT"
  ask_db_pass
  if num=$(pg_q "show server_version_num" 2>"$RUN_DIR/psql.err"); then
    [ "${num:0:2}" = 16 ] && pass "connected as $DB_ADMIN_USER (server $num)" || wfail "server is $num - this tool package is for PostgreSQL 16"
    PG_DATA=$(pg_q "show data_directory")
    DB_BYTES=$(pg_q "select sum(pg_database_size(datname)) from pg_database")
    say "  data dir $PG_DATA, all databases $(gib "$DB_BYTES")"
  else
    wfail "cannot log in as '$DB_ADMIN_USER' on 127.0.0.1:$PG_PORT: $(head -1 "$RUN_DIR/psql.err")"
  fi
else
  wfail "psql not found in '${PG_HOME:-?}/bin'"
fi

# ---- web access / current version ----------------------------------------------
section "Web access and version"
TOOL_SCHEME=${TOOL_SCHEME:-http}; TOOL_HOST=${TOOL_HOST:-127.0.0.1}
NEO_URL_PATH="$CGI_URL/$(basename "${NEO_DIR:-dneo}")/dneo.cgi"
read -r code loc < <(local_curl -o /dev/null -w '%{http_code} %{redirect_url}\n' "${TOOL_SCHEME}://${TOOL_HOST}$NEO_URL_PATH" || echo "000 -")
if [[ $code == 30* ]] && [[ $loc =~ ^(https?)://([^/:]+) ]]; then
  TOOL_SCHEME=${BASH_REMATCH[1]}; TOOL_HOST=${BASH_REMATCH[2]}
  say "  Apache redirects to $TOOL_SCHEME://$TOOL_HOST - using that name, resolved to 127.0.0.1"
  code=$(http_code "$NEO_URL_PATH")
fi
[ "$code" = 200 ] && pass "login page ${TOOL_SCHEME}://${TOOL_HOST}$NEO_URL_PATH -> 200" \
                  || wfail "login page returned HTTP $code (set TOOL_SCHEME/TOOL_HOST)"
VERSION_SEEN=$(neo_version); VERSION_SEEN=${VERSION_SEEN:-unknown}
case "$VERSION_SEEN" in
  "$FROM_VERSION")   pass "current version $VERSION_SEEN" ;;
  "$TARGET_VERSION") wfail "already on $TARGET_VERSION" ;;
  unknown)           wwarn "could not read the version from the login page - you'll be asked to confirm it in 'stop'" ;;
  *)                 wfail "current version is $VERSION_SEEN, expected $FROM_VERSION" ;;
esac

# ---- disk space -----------------------------------------------------------------
section "Disk space"
declare -A NEED_MIN NEED_REC
add_need() { local fs; fs=$(df -P "$1" | awk 'NR==2{print $6}'); NEED_MIN[$fs]=$(( ${NEED_MIN[$fs]:-0} + $2 )); NEED_REC[$fs]=$(( ${NEED_REC[$fs]:-0} + $3 )); }
if [ -n "${PG_DATA:-}" ]; then
  # Optimization needs about the DB size again; the tool's backup needs up to as much again.
  add_need "$PG_DATA" "$DB_BYTES" $(( DB_BYTES * 2 ))
fi
AI_DIR="${NEO_DIR:-/nonexistent}/file/1/aiasst"
if [ -d "$AI_DIR" ]; then
  AI_BYTES=$(du -sb "$AI_DIR" | cut -f1)
  say "  $AI_DIR is $(gib "$AI_BYTES") (roughly doubles during the update)"
  add_need "$AI_DIR" "$AI_BYTES" $(( AI_BYTES + 1073741824 ))
fi
[ -n "$NEO_DIR" ] && add_need "$NEO_DIR" 536870912 1073741824
for fs in "${!NEED_MIN[@]}"; do
  avail=$(df -PB1 "$fs" | awk 'NR==2{print $4}')
  msg="$fs: free $(gib "$avail"), needs >= $(gib "${NEED_MIN[$fs]}") (recommended $(gib "${NEED_REC[$fs]}"))"
  if   [ "$avail" -lt "${NEED_MIN[$fs]}" ]; then wfail "$msg"
  elif [ "$avail" -lt "${NEED_REC[$fs]}" ]; then wwarn "$msg"
  else pass "$msg"; fi
done

# ---- scheduler / real-time server / cron -------------------------------------------
section "Scheduler, real-time server, cron"
if systemctl list-unit-files "$REALTIME_SERVICE.service" 2>/dev/null | grep -q "$REALTIME_SERVICE"; then
  say "  $REALTIME_SERVICE: $(systemctl is-active "$REALTIME_SERVICE" || true), $(systemctl is-enabled "$REALTIME_SERVICE" 2>/dev/null || true)"
else
  say "  $REALTIME_SERVICE: not installed"
fi
procs=$(pgrep -af "$SCHEDULER_PROC_PATTERN" | grep -v pgrep || true)
[ -n "$procs" ] && say "  scheduler running (stop it in NEO admin before 'stop'):" && sed 's/^/      /' <<<"$procs" || say "  scheduler process: not running"
for u in root "$WEBUSER"; do
  m=$(crontab -l -u "$u" 2>/dev/null | grep -vE '^[[:space:]]*#' | grep -E "$CRON_PATTERN" || true)
  [ -n "$m" ] && { say "  crontab($u) lines 'stop' will comment out:"; sed 's/^/      /' <<<"$m"; }
done
m=$(grep -lE "$CRON_PATTERN" /etc/cron.d/* 2>/dev/null || true)
[ -n "$m" ] && say "  /etc/cron.d files with matching lines: $m"

# ---- package download / automation readiness ------------------------------------------
section "Package and automation"
size=$(curl -sfIL --max-time 20 "$TOOL_PKG_URL" | awk 'tolower($1)=="content-length:"{s=$2} END{print s+0}' || true)
[ "${size:-0}" -gt 0 ] && pass "package reachable ($(gib "$size")): $TOOL_PKG_URL" || wfail "cannot reach $TOOL_PKG_URL"
[ -x "$VENV/bin/python" ] && pass "Playwright venv ready ($VENV)" || say "  Playwright not set up yet - run: sudo bash upgrade.sh setup-playwright"
[ -f "$STATE_DIR/stopped" ] && wwarn "services are currently stopped by a previous 'stop' (undo: rollback-services)"

# ---- save -------------------------------------------------------------------------------
{
  for k in CGI_DIR DOCROOT NEO_DIR MOBILE_DIR ANPI_DIR PG_HOME PG_PORT TOOL_SCHEME TOOL_HOST VERSION_SEEN SELINUX; do
    printf '%s=%s\n' "$k" "${!k:-}"
  done
} > "$STATE_DIR/detected.env"

section "Result"
say "  $FAILS failure(s), $WARNS warning(s). Settings saved to $STATE_DIR/detected.env"
if [ "$FAILS" -gt 0 ]; then
  rm -f "$STATE_DIR/precheck.ok"
  exit 1
fi
date +%s > "$STATE_DIR/precheck.ok"
