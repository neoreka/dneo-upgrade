#!/bin/bash
# Phase 50 - run the update tool's screens (updv90/oparation.html).
#   default            Playwright clicks through all 8 screens (asks before completion processing)
#   --discover         open screens 1-2, fill them, submit nothing (safe on production, any time)
#   --manual-wizard    print the values and an SSH tunnel command; you click through yourself
# Other options are passed to wizard.py: --auto-complete --delete-backup --allow-unmatched
source "$(dirname "$0")/../lib.sh"
load_detected

MANUAL=0; DISCOVER=0; PASS=()
for a in "$@"; do
  case "$a" in
    --manual-wizard) MANUAL=1 ;;
    --discover)      DISCOVER=1; PASS+=("$a") ;;
    *)               PASS+=("$a") ;;
  esac
done

[ -f "$CGI_DIR/dneoupd/dneoupd.cgi" ] || die "update tool not installed - run:  upgrade.sh install-tool"
if [ "$DISCOVER" = 0 ] && [ ! -f "$STATE_DIR/stopped" ]; then
  die "services are still running - run 'upgrade.sh stop' first (or use --discover)"
fi

if [ "$MANUAL" = 1 ]; then
  section "Manual installer"
  [ "$TOOL_SCHEME" = https ] && RPORT=443 || RPORT=80
  cat <<EOF
The tool only answers to this server, so open it through an SSH tunnel from your Mac:

  ssh -i KEY.pem -L 8080:127.0.0.1:$RPORT ec2-user@SERVER_IP
  then browse: ${TOOL_SCHEME}://localhost:8080$CGI_URL/dneoupd/dneoupd.cgi
EOF
  [ "$TOOL_HOST" = 127.0.0.1 ] || say "  (Apache expects the name $TOOL_HOST; if you get redirected, add '127.0.0.1 $TOOL_HOST' to /etc/hosts on your Mac and use https://$TOOL_HOST:8080)"
  cat <<EOF

Values for the screens:
  Screen 2  main body (本体)                 $NEO_DIR
            mobile browser version         ${MOBILE_DIR:-(not installed)}
            safety confirmation (安否確認)    ${ANPI_DIR:-(not installed)}
            web server home directory      $DOCROOT
            DB admin user / password       $DB_ADMIN_USER / (the PostgreSQL admin password)
  Screen 3  tick バックアップを行う, PostgreSQL path   $PG_HOME${BACKUP_DIR:+, backup dir $BACKUP_DIR}
  Screen 6  wait until every status is 終了 and none failed before 次へ進む
  Screen 7  leave "delete backup files" unticked
EOF
  confirm "Finished all screens and every status on the completion screen is 終了?" DONE
  exit 0
fi

[ -x "$VENV/bin/python" ] || die "Playwright not set up - run:  upgrade.sh setup-playwright"
ask_db_pass
OUT="$RUN_DIR/screens"
export PLAYWRIGHT_BROWSERS_PATH DNEO_DB_PASS
export DNEO_DB_USER="$DB_ADMIN_USER" DNEO_NEO_DIR="$NEO_DIR" DNEO_MOBILE_DIR="$MOBILE_DIR" \
       DNEO_ANPI_DIR="$ANPI_DIR" DNEO_DOCROOT="$DOCROOT" DNEO_PG_HOME="$PG_HOME" DNEO_BACKUP_DIR="$BACKUP_DIR"

ARGS=(--url "$TOOL_URL" --out "$OUT" --poll "$POLL_SECONDS" --stall-minutes "$STALL_MINUTES"
      --timeout-hours "$UPDATE_TIMEOUT_HOURS")
case "$TOOL_HOST" in 127.0.0.1|localhost) ;; *) ARGS+=(--resolve-host "$TOOL_HOST") ;; esac
[ -f "$STATE_DIR/chromium.path" ] && ARGS+=(--chromium "$(cat "$STATE_DIR/chromium.path")")
[ -n "$FIELD_OVERRIDES" ] && ARGS+=(--overrides "$FIELD_OVERRIDES")

section "Installer (Playwright) - screenshots in $OUT"
[ "$DISCOVER" = 1 ] || date +%s > "$STATE_DIR/wizard.start"
set +e
"$VENV/bin/python" "$UPG_DIR/wizard.py" "${ARGS[@]}" "${PASS[@]}"
rc=$?
set -e
case $rc in
  0) info "installer finished" ;;
  2) die "installer stopped for review (exit 2). Read the log above and $OUT. Services are still stopped." ;;
  3) die "the tool reported problems (exit 3). Check $OUT and the tool's 詳細表示 logs. Services are still stopped." ;;
  *) die "installer script error (exit $rc). See $OUT/*error*. Services are still stopped." ;;
esac
