#!/bin/bash
# Phase 20 - start of the downtime window (pre-update checklist items 2-6).
#   - confirms the AMI and the manual NEO admin steps
#   - blocks user access to /cgi-bin/ (BLOCK_USERS=yes)
#   - comments out scheduler cron lines, stops leftover scheduler processes
#   - stops the real-time server (dneows)
# Undo with:  sudo bash upgrade.sh rollback-services
source "$(dirname "$0")/../lib.sh"
load_detected

section "Before the downtime starts"
[ "$VERSION_SEEN" = unknown ] && VCHECK="
  [ ] This server runs desknet's NEO $FROM_VERSION (precheck couldn't read the version)" || VCHECK=""
confirm "Users are about to be blocked. Confirm ALL of these:
  [ ] An AMI of this instance shows 'available' in the AWS console
  [ ] Users have been told about the downtime
  [ ] Antivirus scans and backup jobs on this server are paused
  [ ] NEO admin: スケジューラ stopped, 文書管理自動取込 / メール自動受信 stopped (if used),
      メール索引の最適化 not running$VCHECK"

# ---- block users ---------------------------------------------------------------
section "User access"
if [ "$BLOCK_USERS" = yes ] && [ -d "$HTTPD_CONF_D" ]; then
  {
    echo "# Added by dneo-upgrade 'stop' on $(date); removed by 'post' / 'rollback-services'."
    echo "<LocationMatch \"^$CGI_URL/(?!dneoupd/)\">"
    echo "    Require local"
    [ -z "$MAINT_ALLOW_IPS" ] || echo "    Require ip $MAINT_ALLOW_IPS"
    echo "    ErrorDocument 403 \"desknet's NEO is being upgraded. Please try again later.\""
    echo "</LocationMatch>"
  } > "$MAINT_CONF"
  httpd_reload
  info "users blocked: $CGI_URL/ now answers 403 except from this server${MAINT_ALLOW_IPS:+ and $MAINT_ALLOW_IPS}"
else
  warn "BLOCK_USERS=$BLOCK_USERS - users can still reach NEO. Data changed during conversion can make the update fail."
fi
touch "$STATE_DIR/stopped"

# ---- scheduler -------------------------------------------------------------------
section "Scheduler"
cron_disable
pids=$(pgrep -f "$SCHEDULER_PROC_PATTERN" || true)
if [ -n "$pids" ]; then
  warn "scheduler still running (pids: $(echo $pids)) - stopping it"
  kill $pids 2>/dev/null || true
  for _ in $(seq 30); do pgrep -f "$SCHEDULER_PROC_PATTERN" >/dev/null || break; sleep 2; done
  pids=$(pgrep -f "$SCHEDULER_PROC_PATTERN" || true)
  [ -z "$pids" ] || { warn "forcing: kill -9 $(echo $pids)"; kill -9 $pids 2>/dev/null || true; }
fi
info "scheduler stopped"

# ---- real-time server ----------------------------------------------------------------
section "Real-time server"
if systemctl list-unit-files "$REALTIME_SERVICE.service" 2>/dev/null | grep -q "$REALTIME_SERVICE"; then
  if [ ! -f "$STATE_DIR/dneows.state" ]; then
    echo "$(systemctl is-active "$REALTIME_SERVICE" || true) $(systemctl is-enabled "$REALTIME_SERVICE" 2>/dev/null || true)" \
      > "$STATE_DIR/dneows.state"
  fi
  systemctl stop "$REALTIME_SERVICE"
  info "$REALTIME_SERVICE stopped (was: $(cat "$STATE_DIR/dneows.state"))"
else
  info "$REALTIME_SERVICE is not installed - skipped"
fi

# ---- anything else still working on NEO data? --------------------------------------------
section "Remaining NEO processes"
others=$(ps -u "$WEBUSER" -o pid=,etime=,args= | grep -vE 'httpd|php-fpm' || true)
if [ -n "$others" ]; then
  say "$others" | sed 's/^/    /'
  confirm "The processes above run as $WEBUSER. Make sure none of them is a NEO batch (e.g. mail index optimization)."
else
  info "no other $WEBUSER processes"
fi
info "downtime window started - services stopped"
